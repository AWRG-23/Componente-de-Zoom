package componentejava;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.AffineTransform;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;


public class PanelZoom extends JPanel {
   
    private double zoomFactor = 1.0;

    public PanelZoom() {
    setLayout(null);

        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                
                    if (SwingUtilities.isLeftMouseButton(e)) {
                        Zoom(zoomFactor * 1.1);
                    } else if (SwingUtilities.isRightMouseButton(e)) {
                        Zoom(zoomFactor / 1.1);
                    }
                
            }
        });
      
       
    }

    public void Zoom(double zoomFactor) {

        this.zoomFactor = Math.max(0.1, zoomFactor);
        revalidate();
        repaint();
    }

    
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        AffineTransform at = g2.getTransform();
        g2.scale(zoomFactor, zoomFactor);
        g2.setTransform(at); 
        }

   protected void paintChildren(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        AffineTransform at = g2.getTransform();
        g2.scale(zoomFactor, zoomFactor);
        super.paintChildren(g2);
        g2.setTransform(at); 
    }

    
    
    
    
    
    
    
    
}
